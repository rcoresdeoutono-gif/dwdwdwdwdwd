# Central de Atendimento — Residencial Cores de Outono

Protótipo navegável da primeira versão.

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra `index.html` em um navegador atualizado.
3. Use um dos números de demonstração:
   - Charles: 41999990000
   - Fernanda: 41988880000
   - Paulo: 41977770000
4. O código de seis dígitos aparece na própria tela. Isso é apenas uma simulação local.

## O que já funciona no protótipo
- Login com lista de telefones autorizados e simulação de código.
- Cadastro, edição, ativação e bloqueio de participantes.
- Perfis de acesso cadastráveis.
- Caixa de atendimentos de demonstração.
- Atribuição de responsável e mudança de status.
- Registro de protocolos.
- Persistência local no navegador via localStorage.

## Limitações importantes
Este protótipo NÃO envia códigos pelo WhatsApp e NÃO envia/recebe mensagens reais. Os dados ficam apenas no navegador usado para abrir o arquivo, sem autenticação segura de servidor. Não use dados reais de moradores nesta versão.

## Próxima etapa para produção
- Criar backend e banco de dados PostgreSQL.
- Implementar autenticação real por OTP via WhatsApp (Meta Cloud API ou provedor autorizado), com expiração, limite de tentativas e proteção contra abuso.
- Criar conta Meta Business, verificar/registrar o número novo e configurar webhooks.
- Integrar envio/recebimento de mensagens e templates conforme as regras da plataforma.
- Implementar permissões no servidor, auditoria, criptografia, backups, política de retenção e adequação à LGPD.
- Publicar em domínio com HTTPS.
